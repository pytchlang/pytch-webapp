import pytch

class BlueOrange(pytch.Sprite):
    Costumes = ["blue-orange-crop-test.png"]

    @pytch.when_green_flag_clicked
    def say_hello(self):
        print("Hello world")
