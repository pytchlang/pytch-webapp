import pytch

# This is a sample project to serve as a valid test fixture zipfile.

class GreenBurst(pytch.Stage):
    Backdrops = ["green-burst.jpg"]
